const Discord = require('discord.js');
const config = require('../../config.json');

module.exports = {
    name: "github",
    aliases: ["sourcecode", "codes", "git"],
    category: "Others",
    description: "Gets you the link to get my source code make sure you star it !!!",
    example: `${config.Prefix}`,

    run: async (client, message, args) => {

        const embed = new Discord.MessageEmbed()
        .setThumbnail(client.user.displayAvatarURL( { dynamic: true, size: 1024 } ))
        .setTitle('not public yet')
        .setDescription(`YEEEEEEEEEEE`)
        .setFooter(`Requested by ${message.author.username}`,  message.author.displayAvatarURL({ dynamic: true }))
        .setTimestamp()

        message.channel.send(embed)

    }
}