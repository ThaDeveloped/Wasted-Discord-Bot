module.exports = async(client, info) => {

    console.log(`Warning: ${info}`)
    
}