module.exports = async(client, error) => {

    console.log(`Error -> ${error}`)
    
}