module.exports = async (client, replayed) => {

    console.log(`WebSocket resumes : ${replayed}`)
    
}