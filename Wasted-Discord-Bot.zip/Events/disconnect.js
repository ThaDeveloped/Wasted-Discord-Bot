module.exports = async (client, event) => {

    console.log(`Client has disconnected to websocket and no longer attempt to reconnect !!`)

}